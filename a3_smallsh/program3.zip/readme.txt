Use "gcc smallish.c -o smallish" to compile

Download the p3testscript

Chmod +x p3testscript

p3testscript smallsh to execute the script
